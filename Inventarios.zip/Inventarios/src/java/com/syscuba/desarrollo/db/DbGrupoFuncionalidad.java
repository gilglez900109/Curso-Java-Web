/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_grupo_funcionalidad")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbGrupoFuncionalidad.findAll", query = "SELECT d FROM DbGrupoFuncionalidad d"),
    @NamedQuery(name = "DbGrupoFuncionalidad.findByIdGrupo", query = "SELECT d FROM DbGrupoFuncionalidad d WHERE d.dbGrupoFuncionalidadPK.idGrupo = :idGrupo"),
    @NamedQuery(name = "DbGrupoFuncionalidad.findByIdFuncionalidad", query = "SELECT d FROM DbGrupoFuncionalidad d WHERE d.dbGrupoFuncionalidadPK.idFuncionalidad = :idFuncionalidad")})
public class DbGrupoFuncionalidad implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected DbGrupoFuncionalidadPK dbGrupoFuncionalidadPK;

    public DbGrupoFuncionalidad() {
    }

    public DbGrupoFuncionalidad(DbGrupoFuncionalidadPK dbGrupoFuncionalidadPK) {
        this.dbGrupoFuncionalidadPK = dbGrupoFuncionalidadPK;
    }

    public DbGrupoFuncionalidad(int idGrupo, int idFuncionalidad) {
        this.dbGrupoFuncionalidadPK = new DbGrupoFuncionalidadPK(idGrupo, idFuncionalidad);
    }

    public DbGrupoFuncionalidadPK getDbGrupoFuncionalidadPK() {
        return dbGrupoFuncionalidadPK;
    }

    public void setDbGrupoFuncionalidadPK(DbGrupoFuncionalidadPK dbGrupoFuncionalidadPK) {
        this.dbGrupoFuncionalidadPK = dbGrupoFuncionalidadPK;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (dbGrupoFuncionalidadPK != null ? dbGrupoFuncionalidadPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbGrupoFuncionalidad)) {
            return false;
        }
        DbGrupoFuncionalidad other = (DbGrupoFuncionalidad) object;
        if ((this.dbGrupoFuncionalidadPK == null && other.dbGrupoFuncionalidadPK != null) || (this.dbGrupoFuncionalidadPK != null && !this.dbGrupoFuncionalidadPK.equals(other.dbGrupoFuncionalidadPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbGrupoFuncionalidad[ dbGrupoFuncionalidadPK=" + dbGrupoFuncionalidadPK + " ]";
    }
    
}
