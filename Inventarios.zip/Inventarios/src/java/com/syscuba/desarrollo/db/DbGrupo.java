/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_grupo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbGrupo.findAll", query = "SELECT d FROM DbGrupo d"),
    @NamedQuery(name = "DbGrupo.findByIdGrupo", query = "SELECT d FROM DbGrupo d WHERE d.idGrupo = :idGrupo"),
    @NamedQuery(name = "DbGrupo.findByNombre", query = "SELECT d FROM DbGrupo d WHERE d.nombre = :nombre"),
    @NamedQuery(name = "DbGrupo.findByDateIn", query = "SELECT d FROM DbGrupo d WHERE d.dateIn = :dateIn"),
    @NamedQuery(name = "DbGrupo.findByDateOut", query = "SELECT d FROM DbGrupo d WHERE d.dateOut = :dateOut")})
public class DbGrupo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idGrupo")
    private Integer idGrupo;
    @Size(max = 45)
    @Column(name = "Nombre")
    private String nombre;
    @Column(name = "DateIn")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateIn;
    @Column(name = "DateOut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateOut;

    public DbGrupo() {
    }

    public DbGrupo(Integer idGrupo) {
        this.idGrupo = idGrupo;
    }

    public Integer getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(Integer idGrupo) {
        this.idGrupo = idGrupo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getDateIn() {
        return dateIn;
    }

    public void setDateIn(Date dateIn) {
        this.dateIn = dateIn;
    }

    public Date getDateOut() {
        return dateOut;
    }

    public void setDateOut(Date dateOut) {
        this.dateOut = dateOut;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idGrupo != null ? idGrupo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbGrupo)) {
            return false;
        }
        DbGrupo other = (DbGrupo) object;
        if ((this.idGrupo == null && other.idGrupo != null) || (this.idGrupo != null && !this.idGrupo.equals(other.idGrupo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbGrupo[ idGrupo=" + idGrupo + " ]";
    }
    
}
