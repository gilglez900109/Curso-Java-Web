/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_session")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbSession.findAll", query = "SELECT d FROM DbSession d"),
    @NamedQuery(name = "DbSession.findByIdSession", query = "SELECT d FROM DbSession d WHERE d.idSession = :idSession"),
    @NamedQuery(name = "DbSession.findByDateStart", query = "SELECT d FROM DbSession d WHERE d.dateStart = :dateStart"),
    @NamedQuery(name = "DbSession.findByDateFinish", query = "SELECT d FROM DbSession d WHERE d.dateFinish = :dateFinish"),
    @NamedQuery(name = "DbSession.findByIdUsuario", query = "SELECT d FROM DbSession d WHERE d.idUsuario = :idUsuario")})
public class DbSession implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idSession")
    private Integer idSession;
    @Column(name = "DateStart")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateStart;
    @Column(name = "DateFinish")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFinish;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idUsuario")
    private int idUsuario;

    public DbSession() {
    }

    public DbSession(Integer idSession) {
        this.idSession = idSession;
    }

    public DbSession(Integer idSession, int idUsuario) {
        this.idSession = idSession;
        this.idUsuario = idUsuario;
    }

    public Integer getIdSession() {
        return idSession;
    }

    public void setIdSession(Integer idSession) {
        this.idSession = idSession;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public void setDateStart(Date dateStart) {
        this.dateStart = dateStart;
    }

    public Date getDateFinish() {
        return dateFinish;
    }

    public void setDateFinish(Date dateFinish) {
        this.dateFinish = dateFinish;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSession != null ? idSession.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbSession)) {
            return false;
        }
        DbSession other = (DbSession) object;
        if ((this.idSession == null && other.idSession != null) || (this.idSession != null && !this.idSession.equals(other.idSession))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbSession[ idSession=" + idSession + " ]";
    }
    
}
