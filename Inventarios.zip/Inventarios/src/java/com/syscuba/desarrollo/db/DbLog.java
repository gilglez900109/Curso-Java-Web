/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_log")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbLog.findAll", query = "SELECT d FROM DbLog d"),
    @NamedQuery(name = "DbLog.findByIdlog", query = "SELECT d FROM DbLog d WHERE d.idlog = :idlog"),
    @NamedQuery(name = "DbLog.findByIdSession", query = "SELECT d FROM DbLog d WHERE d.idSession = :idSession"),
    @NamedQuery(name = "DbLog.findByDateAction", query = "SELECT d FROM DbLog d WHERE d.dateAction = :dateAction"),
    @NamedQuery(name = "DbLog.findByDescripcionObject", query = "SELECT d FROM DbLog d WHERE d.descripcionObject = :descripcionObject"),
    @NamedQuery(name = "DbLog.findByTypeEntity", query = "SELECT d FROM DbLog d WHERE d.typeEntity = :typeEntity"),
    @NamedQuery(name = "DbLog.findByIdAction", query = "SELECT d FROM DbLog d WHERE d.idAction = :idAction"),
    @NamedQuery(name = "DbLog.findByIdEntity", query = "SELECT d FROM DbLog d WHERE d.idEntity = :idEntity")})
public class DbLog implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idlog")
    private Integer idlog;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idSession")
    private int idSession;
    @Column(name = "DateAction")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAction;
    @Lob
    @Column(name = "Object")
    private byte[] object;
    @Size(max = 255)
    @Column(name = "DescripcionObject")
    private String descripcionObject;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TypeEntity")
    private int typeEntity;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idAction")
    private int idAction;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idEntity")
    private int idEntity;

    public DbLog() {
    }

    public DbLog(Integer idlog) {
        this.idlog = idlog;
    }

    public DbLog(Integer idlog, int idSession, int typeEntity, int idAction, int idEntity) {
        this.idlog = idlog;
        this.idSession = idSession;
        this.typeEntity = typeEntity;
        this.idAction = idAction;
        this.idEntity = idEntity;
    }

    public Integer getIdlog() {
        return idlog;
    }

    public void setIdlog(Integer idlog) {
        this.idlog = idlog;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public Date getDateAction() {
        return dateAction;
    }

    public void setDateAction(Date dateAction) {
        this.dateAction = dateAction;
    }

    public byte[] getObject() {
        return object;
    }

    public void setObject(byte[] object) {
        this.object = object;
    }

    public String getDescripcionObject() {
        return descripcionObject;
    }

    public void setDescripcionObject(String descripcionObject) {
        this.descripcionObject = descripcionObject;
    }

    public int getTypeEntity() {
        return typeEntity;
    }

    public void setTypeEntity(int typeEntity) {
        this.typeEntity = typeEntity;
    }

    public int getIdAction() {
        return idAction;
    }

    public void setIdAction(int idAction) {
        this.idAction = idAction;
    }

    public int getIdEntity() {
        return idEntity;
    }

    public void setIdEntity(int idEntity) {
        this.idEntity = idEntity;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idlog != null ? idlog.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbLog)) {
            return false;
        }
        DbLog other = (DbLog) object;
        if ((this.idlog == null && other.idlog != null) || (this.idlog != null && !this.idlog.equals(other.idlog))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbLog[ idlog=" + idlog + " ]";
    }
    
}
