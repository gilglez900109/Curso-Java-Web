/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Jenny and Alex´s
 */
@Embeddable
public class DbGrupoFuncionalidadPK implements Serializable {
    @Basic(optional = false)
    @NotNull
    @Column(name = "idGrupo")
    private int idGrupo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idFuncionalidad")
    private int idFuncionalidad;

    public DbGrupoFuncionalidadPK() {
    }

    public DbGrupoFuncionalidadPK(int idGrupo, int idFuncionalidad) {
        this.idGrupo = idGrupo;
        this.idFuncionalidad = idFuncionalidad;
    }

    public int getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }

    public int getIdFuncionalidad() {
        return idFuncionalidad;
    }

    public void setIdFuncionalidad(int idFuncionalidad) {
        this.idFuncionalidad = idFuncionalidad;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idGrupo;
        hash += (int) idFuncionalidad;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbGrupoFuncionalidadPK)) {
            return false;
        }
        DbGrupoFuncionalidadPK other = (DbGrupoFuncionalidadPK) object;
        if (this.idGrupo != other.idGrupo) {
            return false;
        }
        if (this.idFuncionalidad != other.idFuncionalidad) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbGrupoFuncionalidadPK[ idGrupo=" + idGrupo + ", idFuncionalidad=" + idFuncionalidad + " ]";
    }
    
}
