/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_log_detail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbLogDetail.findAll", query = "SELECT d FROM DbLogDetail d"),
    @NamedQuery(name = "DbLogDetail.findByIdLogDetail", query = "SELECT d FROM DbLogDetail d WHERE d.idLogDetail = :idLogDetail"),
    @NamedQuery(name = "DbLogDetail.findByIdLog", query = "SELECT d FROM DbLogDetail d WHERE d.idLog = :idLog"),
    @NamedQuery(name = "DbLogDetail.findByTypeEntity", query = "SELECT d FROM DbLogDetail d WHERE d.typeEntity = :typeEntity")})
public class DbLogDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_log_detail")
    private Integer idLogDetail;
    @Basic(optional = false)
    @NotNull
    @Column(name = "idLog")
    private int idLog;
    @Lob
    @Column(name = "Object")
    private byte[] object;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TypeEntity")
    private int typeEntity;

    public DbLogDetail() {
    }

    public DbLogDetail(Integer idLogDetail) {
        this.idLogDetail = idLogDetail;
    }

    public DbLogDetail(Integer idLogDetail, int idLog, int typeEntity) {
        this.idLogDetail = idLogDetail;
        this.idLog = idLog;
        this.typeEntity = typeEntity;
    }

    public Integer getIdLogDetail() {
        return idLogDetail;
    }

    public void setIdLogDetail(Integer idLogDetail) {
        this.idLogDetail = idLogDetail;
    }

    public int getIdLog() {
        return idLog;
    }

    public void setIdLog(int idLog) {
        this.idLog = idLog;
    }

    public byte[] getObject() {
        return object;
    }

    public void setObject(byte[] object) {
        this.object = object;
    }

    public int getTypeEntity() {
        return typeEntity;
    }

    public void setTypeEntity(int typeEntity) {
        this.typeEntity = typeEntity;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLogDetail != null ? idLogDetail.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbLogDetail)) {
            return false;
        }
        DbLogDetail other = (DbLogDetail) object;
        if ((this.idLogDetail == null && other.idLogDetail != null) || (this.idLogDetail != null && !this.idLogDetail.equals(other.idLogDetail))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbLogDetail[ idLogDetail=" + idLogDetail + " ]";
    }
    
}
