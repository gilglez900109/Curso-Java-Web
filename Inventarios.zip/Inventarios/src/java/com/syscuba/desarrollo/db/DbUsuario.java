/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syscuba.desarrollo.db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Jenny and Alex´s
 */
@Entity
@Table(name = "db_usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "DbUsuario.findAll", query = "SELECT d FROM DbUsuario d"),
    @NamedQuery(name = "DbUsuario.findByIdUsuario", query = "SELECT d FROM DbUsuario d WHERE d.idUsuario = :idUsuario"),
    @NamedQuery(name = "DbUsuario.findByUsername", query = "SELECT d FROM DbUsuario d WHERE d.username = :username"),
    @NamedQuery(name = "DbUsuario.findByPassword", query = "SELECT d FROM DbUsuario d WHERE d.password = :password"),
    @NamedQuery(name = "DbUsuario.findByNombre", query = "SELECT d FROM DbUsuario d WHERE d.nombre = :nombre"),
    @NamedQuery(name = "DbUsuario.findByApellidos", query = "SELECT d FROM DbUsuario d WHERE d.apellidos = :apellidos"),
    @NamedQuery(name = "DbUsuario.findByDateIn", query = "SELECT d FROM DbUsuario d WHERE d.dateIn = :dateIn"),
    @NamedQuery(name = "DbUsuario.findByDateOut", query = "SELECT d FROM DbUsuario d WHERE d.dateOut = :dateOut")})
public class DbUsuario implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idUsuario")
    private Integer idUsuario;
    @Size(max = 45)
    @Column(name = "Username")
    private String username;
    @Size(max = 45)
    @Column(name = "Password")
    private String password;
    @Size(max = 45)
    @Column(name = "Nombre")
    private String nombre;
    @Size(max = 45)
    @Column(name = "Apellidos")
    private String apellidos;
    @Column(name = "DateIn")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateIn;
    @Column(name = "DateOut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateOut;

    public DbUsuario() {
    }

    public DbUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Date getDateIn() {
        return dateIn;
    }

    public void setDateIn(Date dateIn) {
        this.dateIn = dateIn;
    }

    public Date getDateOut() {
        return dateOut;
    }

    public void setDateOut(Date dateOut) {
        this.dateOut = dateOut;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idUsuario != null ? idUsuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DbUsuario)) {
            return false;
        }
        DbUsuario other = (DbUsuario) object;
        if ((this.idUsuario == null && other.idUsuario != null) || (this.idUsuario != null && !this.idUsuario.equals(other.idUsuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.syscuba.desarrollo.db.DbUsuario[ idUsuario=" + idUsuario + " ]";
    }
    
}
