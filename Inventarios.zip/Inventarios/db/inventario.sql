SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `inventario` DEFAULT CHARACTER SET latin1 ;
USE `inventario` ;

-- -----------------------------------------------------
-- Table `inventario`.`db_funcionalidad`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_funcionalidad` (
  `idFuncionalidad` INT(11) NOT NULL ,
  `Nombre` VARCHAR(255) NULL DEFAULT NULL ,
  `Descripcion` VARCHAR(255) NULL DEFAULT NULL ,
  `idParent` INT(11) NULL DEFAULT NULL ,
  `DateIn` DATETIME NULL ,
  `DateOut` DATETIME NULL ,
  PRIMARY KEY (`idFuncionalidad`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_grupo`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_grupo` (
  `idGrupo` INT(11) NOT NULL ,
  `Nombre` VARCHAR(45) NULL DEFAULT NULL ,
  `DateIn` DATETIME NULL DEFAULT NULL ,
  `DateOut` DATETIME NULL DEFAULT NULL ,
  PRIMARY KEY (`idGrupo`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_usuario`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_usuario` (
  `idUsuario` INT(11) NOT NULL ,
  `Username` VARCHAR(45) NULL DEFAULT NULL ,
  `Password` VARCHAR(45) NULL DEFAULT NULL ,
  `Nombre` VARCHAR(45) NULL DEFAULT NULL ,
  `Apellidos` VARCHAR(45) NULL DEFAULT NULL ,
  `DateIn` DATETIME NULL DEFAULT NULL ,
  `DateOut` DATETIME NULL DEFAULT NULL ,
  PRIMARY KEY (`idUsuario`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_session`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_session` (
  `idSession` INT(11) NOT NULL ,
  `DateStart` DATETIME NULL DEFAULT NULL ,
  `DateFinish` DATETIME NULL DEFAULT NULL ,
  `idUsuario` INT(11) NOT NULL ,
  PRIMARY KEY (`idSession`) ,
  INDEX `fk_db_session_db_usuario1_idx` (`idUsuario` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_log`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_log` (
  `idlog` INT(11) NOT NULL ,
  `idSession` INT(11) NOT NULL ,
  `DateAction` DATETIME NULL DEFAULT NULL ,
  `Object` BLOB NULL DEFAULT NULL ,
  `DescripcionObject` VARCHAR(255) NULL DEFAULT NULL ,
  `TypeEntity` INT NOT NULL ,
  `idAction` INT NOT NULL ,
  `idEntity` INT NOT NULL ,
  PRIMARY KEY (`idlog`) ,
  INDEX `fk_db_log_db_session1_idx` (`idSession` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_log_detail`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_log_detail` (
  `id_log_detail` INT(11) NOT NULL ,
  `idLog` INT(11) NOT NULL ,
  `Object` BLOB NULL DEFAULT NULL ,
  `TypeEntity` INT NOT NULL ,
  PRIMARY KEY (`id_log_detail`) ,
  INDEX `fk_db_log_detail_db_log1_idx` (`idLog` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_grupo_usuario`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_grupo_usuario` (
  `idGrupo` INT(11) NOT NULL ,
  `idUsuario` INT(11) NOT NULL ,
  PRIMARY KEY (`idGrupo`, `idUsuario`) ,
  INDEX `fk_db_grupo_has_db_usuario_db_usuario1_idx` (`idUsuario` ASC) ,
  INDEX `fk_db_grupo_has_db_usuario_db_grupo_idx` (`idGrupo` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `inventario`.`db_grupo_funcionalidad`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `inventario`.`db_grupo_funcionalidad` (
  `idGrupo` INT(11) NOT NULL ,
  `idFuncionalidad` INT(11) NOT NULL ,
  PRIMARY KEY (`idGrupo`, `idFuncionalidad`) ,
  INDEX `fk_db_grupo_has_db_funcionalidad_db_funcionalidad1_idx` (`idFuncionalidad` ASC) ,
  INDEX `fk_db_grupo_has_db_funcionalidad_db_grupo1_idx` (`idGrupo` ASC) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
